
</style>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>doctor_list</title>
</head>
<h1 class="text-white text-center">All The Doctor's List</h1>
<style>
h1{
font-size:50px;
padding-top:60px;
}
h3{
font-size:30px;
}
body {margin:0;
padding:0;
      font: 400 15px/1.8 Lato, sans-serif;
      color: #777;
width:100%;
height:100vh;
background-image:url(../pic/1.jpg);
background-size:cover;
}
</style>
<body class=" display-3 container">
<ul class="text-center font-weight-bold text-monospace text-dark">
<table border="1" cellPadding="13" align="center" 
class="table table-hover table-dark">
 <thead
    <tr>
      
      <th scope="col" class="text-center text-warning " style="font-size:36px">Specialist Name</th>

    </tr>
</thead>
<tr><th class="text-center"><h3><a href=medicine_delete.php>Medicine</a></h3></th></tr>
<tr><th class="text-center"><h3><a href=bone_delete.php>Orthopedic</a></h3></th></tr>
<tr><th class="text-center"><h3><a href=cardiologist_delete.php>Cardiologist</a></h3></th></tr>
<tr><th class="text-center"><h3><a href=surgeon_delete.php>Surgeon</a></h3></th></tr>
<tr><th class="text-center"><h3><a href=dentist_delete.php>Dentist</a></h3></th></tr>
<tr><th class="text-center"><h3><a href=cardiac_delete.php>Cardiac electrophysiologist</a></h3></th></tr>
<tr><th class="text-center"><h3><a href=gynecologist_delete.php>Gynecologist</a></h3></th></tr>
</table>


 
<div class="container ">
<ul class="pager font-weight-bold text-monospace">
  <li class="previous "><a href="view_admin_home_page.php">Previous</a></li>
  <li class="next"><a href="add_doctor.php">Next</a></li>
</ul></div>


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>

</body>
</html>
