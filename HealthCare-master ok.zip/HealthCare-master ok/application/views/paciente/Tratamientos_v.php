        <section id="tratamientos-contenido">
        <h3>Tus tratamientos activos</h3>
            <ul id="lista">
            </ul>
        </section>
        </div>
        </body>